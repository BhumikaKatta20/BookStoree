There are 2 kinds of users:
1->User(who see all the stores )
2->Store user(who will add new book, Update the count of the book, Delete the book)

Main Task of user:
-User will view all the store
-Once He/She Selects the store, all the books present in the store is visible
-Once the User Select the Book and new Web Page will open on Clicking "Get it" button Automatically the count of the book will decrease the count by one.
-The Book which has the count of 0 Gives Out of Stock
