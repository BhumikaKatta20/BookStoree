from django.apps import AppConfig


class BookStoreConfig(AppConfig):
    name = 'Book_Store'
